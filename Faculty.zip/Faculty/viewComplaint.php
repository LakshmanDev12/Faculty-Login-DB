<?php
require('database.php');
session_start();

// Check user role
if ($_SESSION['USERROLE'] != 'admin') {
    header("Location: ..\login.php");
    die();
}

// Check if delete button is clicked and row id is provided
if (isset($_POST['delete_id'])) {
    $delete_id = $_POST['delete_id'];
    
    // Prepare and execute the delete query
    $query = "DELETE FROM uploaded_files WHERE id = ?";
    $stmt = $con->prepare($query);
    $stmt->bind_param("i", $delete_id);
    $stmt->execute();
    $stmt->close();
}

// Fetch data from the database
$query = "SELECT * FROM uploaded_files";
$result = mysqli_query($con, $query);

if (!$result) {
    die("Error: " . mysqli_error($con)); // Handle query execution error
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DIT</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh; /* Change height to min-height */
        }

        .container {
            max-width: 2300px;
            width: 100%; /* Adjust width percentage */
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            overflow-x: auto; /* Add horizontal scrolling for small screens */
        }

        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }

        table th,
        table td {
            border: 1px solid #ddd;
            padding: 15px;
            text-align: left;
        }

        table th {
            background-color: #343a40;
            color: #fff;
            font-weight: bold;
        }

        table tbody td {
            background-color: #f8d7da;
            color: #721c24;
            font-weight: bold;
        }

        .logout-button,
        .download-button,
        .delete-button,
        .redirect-button {
            background-color: #007bff;
            border: none;
            color: white;
            padding: 15px 25px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 18px;
            border-radius: 5px;
            position: relative;
            overflow: hidden;
            transition: background-color 0.3s, transform 0.3s;
            cursor: pointer;
            margin-top: 20px;
        }

        .logout-button:hover,
        .download-button:hover,
        .delete-button:hover,
        .redirect-button:hover {
            background-color: #0056b3;
            transform: translateY(-3px);
        }

        .download-button::before {
            content: "▶";
            font-size: 24px;
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            opacity: 0;
            transition: opacity 0.3s, transform 0.3s;
        }

        .download-button:hover::before {
            opacity: 1;
            left: 10px;
        }

        h2,
        th,
        td {
            color: #343a40;
        }

        /* Media query for smaller screens */
        @media (max-width: 768px) {
            .container {
                width: 95%;
            }
        }

    </style>
</head>

<body>

    <div class="container">
        <!-- Logout button -->
        <a href="index.html" class="logout-button">Logout</a>
        <!-- Title -->
        <h2 style="text-align: center;">MANUAL FOR ACADEMIC PLANNING AND MONITORING</h2>
        <br>
        <!-- Table for displaying data -->
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Academic Year</th>
                    <th>Semester</th>
                    <!-- Add headers for additional text boxes -->
                    <th>PD</th>
                    <th>EXP</th>
                    <th>EQ1</th>
                    <th>EQ2</th>
                    <th>UQ</th>
                    <th>FM</th>
                    <th>RP</th>
                    <th>TLP</th>
                    <th>ACT</th>
                    <th>FDP</th>
                    <th>IV</th>
                    <th>GL</th>
                    <th>WORK</th>
                    <th>LOA</th>
                    <!-- Add header for PDF files -->
                    <th>PDF Files</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    while ($data = mysqli_fetch_assoc($result)) {
                        // Retrieve data for each row
                        $uploaded_text = $data['uploaded_text'];
                        $academicYear = $data['AcademicYear'];

                        $semester = $data['Semester'];
                        $PD = $data['PD'];
                        $EXP = $data['EXP'];
                        $EQ1 = $data['EQ1'];
                        $EQ2 = $data['EQ2'];
                        $UQ = $data['UQ'];
                        $FM = $data['FM'];
                        $RP = $data['RP'];
                        $TLP = $data['TLP'];
                        $ACT = $data['ACT'];
                        $FDP = $data['FDP'];
                        $IV = $data['IV'];
                        $GL = $data['GL'];
                        $WORK = $data['WORK'];
                        $LOA = $data['LOA'];
                        $id = $data['id'];

                ?>
                        <!-- Display each row of data in the table -->
                        <tr>
                            <td><?php echo $uploaded_text ?></td>
                            <td><?php echo $academicYear ?></td>
                            <td><?php echo $semester ?></td>
                            <td><?php echo $PD ?></td>
                            <td><?php echo $EXP ?></td>
                            <td><?php echo $EQ1 ?></td>
                            <td><?php echo $EQ2 ?></td>
                            <td><?php echo $UQ ?></td>
                            <td><?php echo $FM ?></td>
                            <td><?php echo $RP ?></td>
                            <td><?php echo $TLP ?></td>
                            <td><?php echo $ACT ?></td>
                            <td><?php echo $FDP ?></td>
                            <td><?php echo $IV ?></td>
                            <td><?php echo $GL ?></td>
                            <td><?php echo $WORK ?></td>
                            <td><?php echo $LOA ?></td>
                            <td>
                                <!-- Download button -->
                             
                                <!-- Redirect button -->
                                <a href="4.php?id=<?php echo $id; ?>" class="redirect-button">View PDF</a>
                            </td>
                            <td>   <a href="download_all.php?id=<?php echo $id; ?>" class="download-button">Download All</a>

                                <!-- Delete button -->
                                <form method="post">
                                    <input type="hidden" name="delete_id" value="<?php echo $id; ?>">
                                    <button type="submit" class="delete-button">Delete</button>
                                </form></td>
                        </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

</body>

</html>

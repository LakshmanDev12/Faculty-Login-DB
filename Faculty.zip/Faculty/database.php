<?php 

    $con = mysqli_connect("localhost","root","","psg");

    if(!$con)
    {
        echo "data base connection error";
    }
?>
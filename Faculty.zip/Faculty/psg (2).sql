-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 17, 2024 at 01:20 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `psg`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` text DEFAULT NULL,
  `role` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`, `role`) VALUES
(1, 'Admin', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `uploaded_files`
--

CREATE TABLE `uploaded_files` (
  `id` int(11) NOT NULL,
  `AcademicYear` varchar(50) NOT NULL,
  `Semester` varchar(50) NOT NULL,
  `PD` varchar(255) NOT NULL,
  `EXP` varchar(255) NOT NULL,
  `EQ1` varchar(255) NOT NULL,
  `EQ2` varchar(255) NOT NULL,
  `UQ` varchar(255) NOT NULL,
  `FM` varchar(255) NOT NULL,
  `RP` varchar(255) NOT NULL,
  `TLP` varchar(255) NOT NULL,
  `ACT` varchar(255) NOT NULL,
  `FDP` varchar(255) NOT NULL,
  `IV` varchar(255) NOT NULL,
  `GL` varchar(255) NOT NULL,
  `WORK` varchar(255) NOT NULL,
  `LOA` varchar(255) NOT NULL,
  `file_name1` varchar(255) NOT NULL,
  `file_content1` longblob NOT NULL,
  `file_name2` varchar(255) NOT NULL,
  `file_content2` longblob NOT NULL,
  `file_name3` varchar(255) NOT NULL,
  `file_content3` longblob NOT NULL,
  `file_name4` varchar(255) NOT NULL,
  `file_content4` longblob NOT NULL,
  `file_name5` varchar(255) NOT NULL,
  `file_content5` longblob NOT NULL,
  `uploaded_text` text DEFAULT NULL,
  `upload_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `uploaded_files`
--
ALTER TABLE `uploaded_files`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `uploaded_files`
--
ALTER TABLE `uploaded_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

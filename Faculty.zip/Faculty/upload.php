<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "psg";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Escape user inputs for security
$uploaded_text = mysqli_real_escape_string($conn, $_POST['name']);
$AcademicYear = mysqli_real_escape_string($conn, $_POST['year']);
$Semester = mysqli_real_escape_string($conn, $_POST['sem']);
$PD = mysqli_real_escape_string($conn, $_POST['PD']);
$EXP = mysqli_real_escape_string($conn, $_POST['EXP']);
$EQ1 = mysqli_real_escape_string($conn, $_POST['EQ1']);
$EQ2 = mysqli_real_escape_string($conn, $_POST['EQ2']);
$UQ = mysqli_real_escape_string($conn, $_POST['UQ']);
$FM = mysqli_real_escape_string($conn, $_POST['FM']);
$RP = mysqli_real_escape_string($conn, $_POST['RP']);
$TLP = mysqli_real_escape_string($conn, $_POST['TLP']);
$ACT = mysqli_real_escape_string($conn, $_POST['ACT']);
$FDP = mysqli_real_escape_string($conn, $_POST['FDP']);
$IV = mysqli_real_escape_string($conn, $_POST['IV']);
$GL = mysqli_real_escape_string($conn, $_POST['GL']);
$WORK = mysqli_real_escape_string($conn, $_POST['WORK']);
$LOA = mysqli_real_escape_string($conn, $_POST['LOA']);

// Insert data into database
$sql = "INSERT INTO uploaded_files (uploaded_text, AcademicYear, Semester, PD, EXP, EQ1, EQ2, UQ, FM, RP, TLP, ACT, FDP, IV, GL, WORK, LOA) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    echo "Error preparing statement: " . $conn->error;
} else {
    $stmt->bind_param("sssssssssssssssss", $uploaded_text, $AcademicYear, $Semester, $PD, $EXP, $EQ1, $EQ2, $UQ, $FM, $RP, $TLP, $ACT, $FDP, $IV, $GL, $WORK, $LOA);

    if ($stmt->execute()) {
        // Redirect to another page
        header("Location: pdf.php");
        exit;}
         else {
        echo "Error executing statement: " . $stmt->error;
    }
}

// Close connection
$conn->close();
?>

<?php 
include('database.php');
session_start();


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
    <title>DIT</title>
    <link rel="shortcut icon" href="asserts\Images\iclogo.png" />    
           <!-- bootstrap v4 -->
    <link rel="stylesheet" href="bootstrap.css">
    <!-- custom css -->
    

        
		<style>
			/* ... Existing styles ... */
			
			.scrolling-text {
			  white-space: nowrap;
			  overflow: hidden;
			  width: 100%;
			  animation: marquee 20s linear infinite;
			}
			
			@keyframes marquee {
			  0% {
				transform: translateX(100%);
			  }
			  100% {
				transform: translateX(-100%);
			  }
			}
			
			/* ... Existing styles ... */

			.custom-button {
      background-color: #373737; /* Background color */
      color: rgba(255, 255, 255, 0.5); /* Text color */
      border: none; /* Remove border */
      padding: 0.375rem 0.75rem; /* Padding */
      text-align: center;
      text-decoration: none; /* Remove underlines */
      display: inline-block;
      font-size: 1rem;
      cursor: pointer;
    }

    .custom-button:hover {
      color: rgba(255, 255, 255, 0.75); /* Text color on hover */
    }
    div.backBtn {
  width: 100px;
  left: 40px;
  top: 60px;
  background-color: #f4f4f4;
  transition: all 0.4s ease;
  position: relative;
  cursor: pointer;
}

span.line {
  bottom: auto;
  right: auto;
  top: auto;
  left: auto;
  background-color: #333;
  border-radius: 10px;
  width: 100%;
  left: 0px;
  height: 2px;
  display: block;
  position: absolute;
  transition: width 0.2s ease 0.1s, left 0.2s ease, transform 0.2s ease 0.3s, background-color 0.2s ease;
}

span.tLine {
  top: 0px;
}

span.mLine {
  top: 13px;
  opacity: 0;
}

span.bLine {
  top: 26px;
}

.label {
  position: absolute;
  left: 0px;
  top: 5px;
  width: 100%;
  text-align: center;
  transition: all 0.4s ease;
  font-size: 1em;
}

div.backBtn:hover span.label {
  left: 25px
}

div.backBtn:hover span.line {
  left: -10px;
  height: 5px;
  background-color: #F76060;
}

div.backBtn:hover span.tLine {
  width: 25px;
  transform: rotate(-45deg);
  left: -15px;
  top: 6px;
}

div.backBtn:hover span.mLine {
  opacity: 1;
  width: 30px;
}

div.backBtn:hover span.bLine {
  width: 25px;
  transform: rotate(45deg);
  left: -15px;
  top: 20px;
}
			</style>
			

    <section id="home">
        <div class="backBtn">
            <a href="index.html">
                <span class="line tLine"></span>
                <span class="line mLine"></span>
                <span class="label" style="color:green;">Back</span>
                <span class="line bLine"></span>
            </a>
        </div>
        <center>
            <br><br><br><br>
            <h1>MANUAL FOR ACADEMIC PLANNING AND MONITORING</h1>
        </center>
        <br><br>
    </section>

    <!-- Events Section -->
    <section id="events" class="container mt-3">
    <form action="upload.php" method="post" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="name" class="form-label">NAME OF THE FACULTY</label>
                <input type="text" class="form-control" id="name" name="name" required>
                <small id="nameHelp" class="form-text text-muted">Capitalize your Name [Remain the name to enter in upcoming pages]</small>
            </div>
            <br>
            <div class="mb-3">
                <label for="year" class="form-label">ACADEMIC YEAR</label>
                <input type="text" class="form-control" id="year" name="year" required>
                <small id="nameHelp" class="form-text text-muted">Syntax as 2023 - 2024</small>
            </div>
            <br>
            <div class="mb-3">
                <label for="sem" class="form-label">SEMESTER</label>
                <input type="text" class="form-control" id="sem" name="sem" required>
                <small id="nameHelp" class="form-text text-muted">Only boolean value Odd or Even</small>
            </div>
            <br>
            <div class="mb-3">
    <label for="textbox2" class="form-label">Present Designation</label>
    <input type="text" class="form-control" id="PD" name="PD" required>
    <small id="textbox2Help" class="form-text text-muted">Need correct one</small>
</div>
<br>

<div class="mb-3">
    <label for="textbox3" class="form-label">Date Of Joining</label>
    <input type="text" class="form-control" id="EXP" name="EXP" required>
    <small id="textbox3Help" class="form-text text-muted">Additional text box</small>
</div>
<br>

<!-- Repeat the above structure for textbox 4 to 11 -->
<div class="mb-3">
    <label for="textbox4" class="form-label">Experience</label>
    <input type="text" class="form-control" id="EQ1" name="EQ1" required>
    <small id="textbox4Help" class="form-text text-muted">Additional text box</small>
</div>
<br>

<!-- Repeat for textbox 5 to 11 -->

<!-- Textbox 5 -->
<div class="mb-3">
    <label for="textbox5" class="form-label">Education Qualification-1</label>
    <input type="text" class="form-control" id="EQ2" name="EQ2" required>
    <small id="textbox5Help" class="form-text text-muted">Present</small>
</div>
<br>

<!-- Textbox 6 -->
<div class="mb-3">
    <label for="textbox6" class="form-label">Education Qualification-2</label>
    <input type="text" class="form-control" id="UQ" name="UQ" required>
    <small id="textbox6Help" class="form-text text-muted">Higher from University/Organization</small>
</div>
<br>

<!-- Textbox 7 -->
<div class="mb-3">
    <label for="textbox7" class="form-label">Specific Period when next Upgrading qualification</label>
    <input type="text" class="form-control" id="FM" name="FM" required>
    <small id="textbox7Help" class="form-text text-muted">Additional text box</small>
</div>
<br>

<!-- Textbox 8 -->
<div class="mb-3">
    <label for="textbox8" class="form-label">FDP/SEMINAR/WORKSHOP PARTICIPATED BY FACULTY MEMBERS</label>
    <input type="text" class="form-control" id="RP" name="RP" required>
    <small id="textbox8Help" class="form-text text-muted">Refershers Courses/Orientation Programme/Training Programme/Conference Attended</small>
</div>
<br>

<!-- Textbox 9 -->
<div class="mb-3">
    <label for="textbox9" class="form-label">Research Paper/Article/Book Published by Faculty Members</label>
    <input type="text" class="form-control" id="TLP" name="TLP" required>
    <small id="textbox9Help" class="form-text text-muted">Title/Research Paper/Article/Book published</small>
</div>
<br>

<!-- Textbox 10 -->
<div class="mb-3">
    <label for="textbox10" class="form-label">Innovationss in Teaching Learning process</label>
    <input type="text" class="form-control" id="ACT" name="ACT" required>
    <small id="textbox10Help" class="form-text text-muted">Faculty Innovations in Teaching Learning Process monitoring Chart</small>
</div>
<br>

<!-- Textbox 11 -->
<div class="mb-3">
    <label for="textbox11" class="form-label">Activities Conducted During Academic</label>
    <input type="text" class="form-control" id="FDP" name="FDP" required>
    <small id="textbox11Help" class="form-text text-muted">List Of Actvities Conducted During Academic Year</small>
</div>
<br>
<div class="mb-3">
    <label for="textbox8" class="form-label">Co-curricular Activities Conducted Outside the Campus during Academic Year</label>
    <input type="text" class="form-control" id="IV" name="IV" required>
    <small id="textbox8Help" class="form-text text-muted">Detailed List of Co-curricular Activities Conducted Outside the Campus during Academic Year</small>
</div>
<br>

<!-- Textbox 9 -->
<div class="mb-3">
    <label for="textbox9" class="form-label">FDP / SDP COUNDECTED DURING ACADEMIC YEAR</label>
    <input type="text" class="form-control" id="GL" name="GL" required>
    <small id="textbox9Help" class="form-text text-muted">FDP / SDP COUNDECTED DURING ACADEMIC YEAR</small>
</div>
<br>

<!-- Textbox 10 -->
<div class="mb-3">
    <label for="textbox10" class="form-label">Textbox 14</label>
    <input type="text" class="form-control" id="WORK" name="WORK" required>
    <small id="textbox10Help" class="form-text text-muted">Additional text box</small>
</div>
<br>

<!-- Textbox 11 -->
<div class="mb-3">
    <label for="textbox11" class="form-label">Textbox 15</label>
    <input type="text" class="form-control" id="LOA" name="LOA" required>
    <small id="textbox11Help" class="form-text text-muted">Additional text box</small>
</div>
<br>



    <!-- Add other complaint fields here -->

    <form action="upload.php" method="post" enctype="multipart/form-data" onsubmit="return validateForm()">
    <!-- Your form fields here -->
    <input type="submit" value="Upload PDF" name="submit">
</form>


           
    </section>
    <script>
        function validateForm() {
            var name = document.getElementById("name").value;
            var year = document.getElementById("year").value;
            var sem = document.getElementById("sem").value;
            var PD = document.getElementById("PD").value;
            var EXP = document.getElementById("EXP").value;
            var EQ1 = document.getElementById("EQ1").value;
            var EQ2 = document.getElementById("EQ2").value;
            var UQ = document.getElementById("UQ").value;
            var FM = document.getElementById("FM").value;
            var RP = document.getElementById("RP").value;
            var TLP = document.getElementById("TLP").value;
            var ACT = document.getElementById("ACT").value;
            var FDP = document.getElementById("FDP").value;
            var IV = document.getElementById("IV").value;
            var GL = document.getElementById("GL").value;
            var WORK = document.getElementById("WORK").value;
            var LOA = document.getElementById("LOA").value;

            if (name == "" || year == "" || sem == "" || PD == "" || EXP == "" || EQ1 == "" || EQ2 == "" || UQ == "" || FM == "" || RP == "" || TLP == "" || ACT == "" || FDP == "" || IV == "" || GL == "" || WORK == "" || LOA == "") {
                alert("Please fill in all fields.");
                return false;
            }
            return true;
        }
    </script>
    <script src="bootstrap.min.js"></script>
    <!-- Other custom scripts if any -->
</body>
</html>

    
  
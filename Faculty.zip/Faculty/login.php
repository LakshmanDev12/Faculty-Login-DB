<?php
include('database.php');
session_start();

?>
<?php 
    
    $msg="";

    if (isset($_POST['submit'])) {
        /* echo "<pre>";
        print_r($_POST);*/
        $username = mysqli_real_escape_string($con,$_POST['username']);
        $password = mysqli_real_escape_string($con,$_POST['password']);

        $sql = mysqli_query($con,"select * from login where username='$username' && password='$password'");
        $num=mysqli_num_rows($sql);

        if ($num>0) {
            /*echo "login";*/
            $row=mysqli_fetch_assoc($sql);

            $_SESSION['USERID']=$row['id'];
            $_SESSION['USERNAME']=$row['username'];
            $_SESSION['USERROLE']=$row['role'];
            $userole=$row['role'];

            if ($userole == 'admin' || $userole == 'Admin'){
                header("location: viewComplaint.php");
            }
          

        }
        else{
            $msg="Please Enter Valid Details !";
        }
    }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login Page</title>
    <link rel="stylesheet" href="ootstrap.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <link rel="stylesheet" href="bootstrap.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <style>
        body {
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('your-background-image.jpg') center/cover no-repeat;
            font-family: 'Arial', sans-serif;
            color: #fff;
            margin: 0;
            padding: 0;
            height: 100vh;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-container {
            max-width: 400px;
            margin: 0 auto;
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px 0px #000000;
        }

        .card-header {
            background-color: #57acd3;
            color: #fff;
            text-align: center;
            padding: 10px;
            border-radius: 8px 8px 0 0;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
        }

        .btn-primary {
            background-color: #57acd3;
            border: none;
            padding: 10px;
            width: 100%;
            border-radius: 5px;
            font-weight: bold;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }

        .error-msg {
            color: #dc3545;
            margin-top: 10px;
        }

        /* Add animation for a subtle effect */
        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        .login-container {
            animation: fadeIn 0.8s ease-in-out;
        }

        div.backBtn {
  width: 100px;
  left: 40px;
  top: 100px;
  background-color: #f4f4f4;
  transition: all 0.4s ease;
  position: fixed;
  cursor: pointer;
}

span.line {
  bottom: auto;
  right: auto;
  top: auto;
  left: auto;
  background-color: #333;
  border-radius: 10px;
  width: 100%;
  left: 0px;
  height: 2px;
  display: block;
  position: absolute;
  transition: width 0.2s ease 0.1s, left 0.2s ease, transform 0.2s ease 0.3s, background-color 0.2s ease;
}

span.tLine {
  top: 0px;
}

span.mLine {
  top: 13px;
  opacity: 0;
}

span.bLine {
  top: 26px;
}

.label {
  position: absolute;
  left: 0px;
  top: 5px;
  width: 100%;
  text-align: center;
  transition: all 0.4s ease;
  font-size: 1em;
}

div.backBtn:hover span.label {
  left: 25px
}

div.backBtn:hover span.line {
  left: -10px;
  height: 5px;
  background-color: #F76060;
}

div.backBtn:hover span.tLine {
  width: 25px;
  transform: rotate(-45deg);
  left: -15px;
  top: 6px;
}

div.backBtn:hover span.mLine {
  opacity: 1;
  width: 30px;
}

div.backBtn:hover span.bLine {
  width: 25px;
  transform: rotate(45deg);
  left: -15px;
  top: 20px;
}
		
    </style>
</head>
<body>
    <div class="backBtn"><a href="index.html">
    <span class="line tLine"></span>
    <span class="line mLine"></span>
    <span class="label" style="color:black;">Back</span>
    <span class="line bLine"></span></a>
</div>

<div class="container login-container">
    <div class="card">
        <div class="card-header">
            <h3>Login</h3>
        </div>

        <div class="card-body">
            <form action="login.php" method="post">
                <div class="form-group">
                    <label for="username"style="color:black">Username</label>
                    <input type="text" name="username" class="form-control" id="username" placeholder="Enter username" required>
                </div>

                <div class="form-group">
                    <label for="password"style="color:black">Password</label>
                    <input type="password" name="password" class="form-control" id="password" placeholder="Password" required>
                </div>
                
                <button type="submit" name="submit" value="Login" class="btn btn-primary">Login</button>

                <?php if (!empty($msg)): ?>
                    <div class="error-msg"><?php echo $msg; ?></div>
                <?php endif; ?>
            </form>
        </div>
    </div>
</div>
</body>
</html>

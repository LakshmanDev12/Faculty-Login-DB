
<?php 
header("location:index.html");
die();
?> 
<?php
    require_once('../database/database.php');

    
    if(isset($_GET['complaintDelete']))
    {
        $complaintId = $_GET['complaintDelete'];
        $query = " delete from complaints where id = '".$complaintId."' ";
        $result = mysqli_query($con,$query);

        if($result)
        {               
            header("location:viewComplaint.php");
        }
        else
        {
            echo ' Please Check Your Query ';
        }
    }
?>
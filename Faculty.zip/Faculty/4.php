<?php
// Establish database connection
$pdo = new PDO('mysql:host=localhost;dbname=psg', 'root', '');

// Array to hold messages for user feedback
$messages = [];

// Handle file uploads when form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if any files were uploaded
    if (!empty(array_filter($_FILES['pdfFiles']['name']))) {
        // Iterate over each uploaded file
        foreach ($_FILES['pdfFiles']['tmp_name'] as $key => $tmp_name) {
            $fileName = $_FILES['pdfFiles']['name'][$key];
            $fileType = pathinfo($fileName, PATHINFO_EXTENSION);

            // Check if the file type is PDF
            if (strtolower($fileType) === 'pdf') {
                $fileContent = file_get_contents($tmp_name);

                // Insert the PDF content into the database
                $stmt = $pdo->prepare("INSERT INTO uploaded_files (file_name, file_content) VALUES (:file_name, :file_content)");
                $stmt->bindParam(':file_name', $fileName);
                $stmt->bindParam(':file_content', $fileContent, PDO::PARAM_LOB);
                if ($stmt->execute()) {
                    $messages[] = "File '$fileName' uploaded successfully.";
                } else {
                    $messages[] = "Error uploading file '$fileName'.";
                }
            } else {
                $messages[] = "File '$fileName' is not a PDF.";
            }
        }
    } else {
        $messages[] = "No files uploaded.";
    }
}

// Retrieve uploaded PDF files from the database
$stmt = $pdo->query("SELECT * FROM uploaded_files");
$uploadedFiles = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Uploaded PDF Files</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }
        h2 {
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f0f0f0;
        }
        .pdf-link {
            display: block;
            margin-bottom: 10px;
        }
        .pdf-link:hover {
            text-decoration: underline;
        }
        .message {
            padding: 10px;
            background-color: #f0f0f0;
            border: 1px solid #ccc;
            margin-bottom: 10px;
        }
        .back-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }
        .back-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body> <a href="index.html" class="back-button">Back</a>
    <h2>Uploaded PDF Files</h2>
    
    <?php foreach ($messages as $message): ?>
        <div class="message"><?php echo $message; ?></div>
    <?php endforeach; ?>
    <?php foreach ($uploadedFiles as $file): ?>
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>PDF 1</th>
                <th>PDF 2</th>
                <th>PDF 3</th>
                <th>PDF 4</th>
                <th>PDF 5</th> 
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo $file['uploaded_text']; ?></td>
                <td><a class="pdf-link" href="data:application/pdf;base64,<?php echo base64_encode($file['file_content1']); ?>" target="_blank">View PDF</a></td>
                <td><a class="pdf-link" href="data:application/pdf;base64,<?php echo base64_encode($file['file_content2']); ?>" target="_blank">View PDF</a></td>
                <td><a class="pdf-link" href="data:application/pdf;base64,<?php echo base64_encode($file['file_content3']); ?>" target="_blank">View PDF</a></td>
                <td><a class="pdf-link" href="data:application/pdf;base64,<?php echo base64_encode($file['file_content4']); ?>" target="_blank">View PDF</a></td>
                <td><a class="pdf-link" href="data:application/pdf;base64,<?php echo base64_encode($file['file_content5']); ?>" target="_blank">View PDF</a></td>
            </tr>
        </tbody>
    </table>
    <?php endforeach; ?>

    <!-- Back button -->
   
</body>
</html>

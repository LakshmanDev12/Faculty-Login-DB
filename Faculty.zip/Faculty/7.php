<?php
// Establish database connection
$pdo = new PDO('mysql:host=localhost;dbname=psg', 'root', '');

// Array to hold messages for user feedback
$messages = [];

// Handle file uploads when form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if input text and files are provided
    if (!empty($_POST['textbox']) && !empty($_FILES['pdfFiles'])) {
        // Get the input text and sanitize it
        $inputText = trim($_POST['textbox']);

        // Check if the input text matches any entry in the database
        $stmt_check = $pdo->prepare("SELECT id FROM uploaded_files WHERE uploaded_text = :uploaded_text");
        $stmt_check->bindParam(':uploaded_text', $inputText);
        $stmt_check->execute();

        if ($stmt_check->rowCount() > 0) {
            // If a match is found, proceed with file upload
            $row = $stmt_check->fetch(PDO::FETCH_ASSOC);
            $fileId = $row['id'];

            // Check if the file type is PDF
            $fileType = pathinfo($_FILES['pdfFiles']['name'][0], PATHINFO_EXTENSION);
            if (strtolower($fileType) === 'pdf') {
                // Read the file content
                $pdfContent = file_get_contents($_FILES['pdfFiles']['tmp_name'][0]);
                $fileName = $_FILES['pdfFiles']['name'][0];

                // Define the column names
                $columnName = "file_content4";
                $nameColumnName = "file_name4";

                // Insert the file content and name into the database row where uploaded_text matches
                $stmt_update = $pdo->prepare("UPDATE uploaded_files SET $nameColumnName = :file_name, $columnName = :file_content WHERE id = :file_id");
                $stmt_update->bindParam(':file_name', $fileName);
                $stmt_update->bindParam(':file_content', $pdfContent, PDO::PARAM_LOB);
                $stmt_update->bindParam(':file_id', $fileId);
                if ($stmt_update->execute()) {
                    $messages[] = "File '$fileName' uploaded successfully.";
                    // Redirect to another page
                    header("Location: 8.php");
                    exit;
                }  else {
                    $messages[] = "Error uploading file '$fileName'.";
                }
            } else {
                $messages[] = "File is not a PDF.";
            }
        } else {
            $messages[] = "No matching entry found in the database.";
        }
    } else {
        $messages[] = "Please provide both text input and a PDF file.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload PDF</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f3f5f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        
        .container {
            background: linear-gradient(to right, #4e54c8, #8f94fb);
            border-radius: 10px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
            padding: 40px;
            max-width: 400px;
            width: 90%;
            color: #fff;
            text-align: center;
            position: relative;
        }

        h2 {
            margin-bottom: 20px;
            font-size: 28px;
        }

        form {
            margin-bottom: 20px;
        }

        input[type="file"] {
            margin-bottom: 20px;
            border: none;
            background-color: rgba(255, 255, 255, 0.7);
            padding: 12px 20px;
            border-radius: 25px;
            width: calc(100% - 40px);
            box-sizing: border-box;
            color: #333;
            font-size: 16px;
            outline: none;
        }

        input[type="text"] {
            margin-bottom: 20px;
            border: none;
            background-color: rgba(255, 255, 255, 0.7);
            padding: 12px 20px;
            border-radius: 25px;
            width: calc(100% - 40px);
            box-sizing: border-box;
            color: #333;
            font-size: 16px;
            outline: none;
        }

        button[type="submit"] {
            background-color: #6c5ce7;
            color: #fff;
            border: none;
            padding: 12px 40px;
            border-radius: 25px;
            cursor: pointer;
            font-size: 18px;
            transition: background-color 0.3s;
        }

        button[type="submit"]:hover {
            background-color: #4834d4;
        }

        .message {
            padding: 10px;
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 16px;
        }

        .upload-icon {
            position: absolute;
            top: -40px;
            left: 50%;
            transform: translateX(-50%);
            font-size: 40px;
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="container">
        <span class="upload-icon">📁</span>
        <h2>Material Preparation</h2>
        
        <?php foreach ($messages as $message): ?>
            <div class="message"><?php echo $message; ?></div>
        <?php endforeach; ?>

        <form action="" method="post" enctype="multipart/form-data">
            <input type="file" name="pdfFiles[]" accept=".pdf">
            <input type="text" name="textbox" placeholder="Enter Text">
            <br>
           [As same as before You entered]<br><br>
            <button type="submit">Upload</button>
        </form>
        
        <button type="submit"><a href="6.php"style="color:white">Back</button></a>
    </div>
</body>
</html>
